package com.meritamerica.assignment2;

public class BankAccount {
	private long AccountNumber;
	private double Balance;
	private double InterestRate;
	private boolean withdraw;
	private boolean deposit;
	private double futureValue;
	
	//Constructor
	public BankAccount(double balance, double interestRate) {
		super();
		Balance = balance;
		InterestRate = interestRate;
	}
	
	

public BankAccount(long accountNumber, double balance, double interestRate) {
		super();
		AccountNumber = accountNumber;
		Balance = balance;
		InterestRate = interestRate;
	}




//getter & setter

	public long getAccountNumber() {
		return AccountNumber;
	}


	public double getBalance() {
		return Balance;
	}

	public double getInterestRate() {
		return InterestRate;
	}

	public boolean withdraw(double amount) {
		if (amount <= Balance && !(amount < 0)) {
			Balance -= amount;
			return true;

		} else
			return false;

	}

	public boolean deposit(double amount) {
		if (amount > 0) {
			Balance += amount;
			return true;
		} else
			return false;

	}

	public double futureValue(int years) {
		double interest = 1.0001;
		double p = 100.0;
		return Math.pow(interest, years) * p;

	}

}
