package com.meritamerica.assignment2;

public class CDOffering {
	
	//Initial Variable
	
	private int Term;
	private double InterestRate;
	

//Constructor
	public CDOffering(int term, double interestRate) {
		super();
		Term = term;
		InterestRate = interestRate;
	}

	//Getter & Setter
	public int getTerm() {
		return Term;
	}


	public double getInterestRate() {
		return InterestRate;
	}
	
	

	
	
	
	
	
	

}
