package com.meritamerica.assignment2;

import java.util.Date;

public class CDAccount {
	private double Balance;
	private double InterestRate;
	private int Term;
	private java.util.Date StartDate;
	private long AccountNumber;
	private double futureValue;
	private CDOffering offering;
	 
//Constructor

	
	public CDAccount(CDOffering offering, double balance) {
		super();
		Balance = balance;
		this.offering = offering;
	}
	
	
	
}
